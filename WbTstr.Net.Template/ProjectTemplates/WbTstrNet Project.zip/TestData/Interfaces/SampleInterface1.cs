﻿namespace $safeprojectname$.TestData.Interfaces
{
    class SampleInterface1
    {
    }
}
