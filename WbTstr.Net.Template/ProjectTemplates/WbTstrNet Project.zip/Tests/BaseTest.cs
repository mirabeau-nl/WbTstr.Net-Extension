﻿using FluentAutomation;
using NUnit.Framework;



namespace $safeprojectname$.Tests
{

    public class BaseTest : FluentTest
    {

        [SetUp]
        public void Init()
        {
            WbTstr.Configure()
            .PreferedBrowser().IsChrome();
            WbTstr.Bootstrap();
        }

    }
}



