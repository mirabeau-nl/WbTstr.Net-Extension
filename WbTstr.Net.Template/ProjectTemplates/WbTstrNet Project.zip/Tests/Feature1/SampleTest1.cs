﻿using NUnit.Framework;

namespace $safeprojectname$.Tests.Feature1
{
 
    public class SampleTests : BaseTest
    {


        [TestCase]
        public void Test1()
        {
            
        }
    }
}



