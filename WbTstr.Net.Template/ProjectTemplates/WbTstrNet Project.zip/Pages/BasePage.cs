﻿namespace $safeprojectname$.Pages
{
    class BasePage
    {
    }
}
