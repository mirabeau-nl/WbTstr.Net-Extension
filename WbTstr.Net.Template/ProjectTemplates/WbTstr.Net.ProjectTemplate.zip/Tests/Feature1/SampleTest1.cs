﻿using NUnit.Framework;
using FluentAutomation;
using $safeprojectname$.Pages;

namespace $safeprojectname$
{
 
    public class SampleTests : FluentTest
    {

        [SetUp]
        public void Init()
        {
        SeleniumWebDriver.Bootstrap(
                SeleniumWebDriver.Browser.Chrome
            );
        }


        [TestCase]
        public void Test1()
        {
            new SamplePage1(this)
                .Go();
        }
    }
}



