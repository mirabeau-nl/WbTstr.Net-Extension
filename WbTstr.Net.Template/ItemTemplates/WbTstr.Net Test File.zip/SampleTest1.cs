﻿using FluentAutomation;
using NUnit.Framework;


namespace $rootnamespace$
{
 
    public class SampleTests : FluentTest
    {

        [SetUp]
        public void Init()
        {
        SeleniumWebDriver.Bootstrap(
                SeleniumWebDriver.Browser.Chrome
            );
        }


        [TestCase]
        public void Test1()
        {
            
        }
    }
}



