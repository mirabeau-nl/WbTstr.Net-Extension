﻿using NUnit.Framework;

namespace $rootnamespace$
{
 
    public class SampleTests : BaseTest
    {


        [TestCase]
        public void Test1()
        {
            
        }
    }
}



