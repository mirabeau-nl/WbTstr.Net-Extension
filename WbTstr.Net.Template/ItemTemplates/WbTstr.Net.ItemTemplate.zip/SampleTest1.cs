﻿using System.Collections.Generic;
using System.Collections.Specialized;
using NUnit.Framework;
using WbTstr.Net.Helpers;
using WbTstr.Net.Objects;
using WbTstr.Net_Project_Template.TestData.Feature1.Pages;

namespace WbTstr.Net_Project_Template
{
 
    public class SampleTests : DriverLoader
    {

        [SetUp]
        public void Init()
        {
            BrowserConfigs = new List<BrowserConfig>
            {
                new BrowserConfig
                {
                    Name = "chrome31",
                    Capabilities = new Dictionary<string, object>
                    {
                       {"browser", "Firefox"},
                       {"browser_version", "31.0"},
                       {"os", "Windows"},
                       {"os_version", "7"},
                       {"resolution", "1024x768"},
                       {"browserstack.debug", "true"},
                       {"browserstack.user", "xxx"},
                       {"browserstack.key", "xxx"},
                       {"browserstack.local", "true"} 
                    }                    
                }
            };

            SetBrowser("chrome31");
        }


        [TestCase]
        public void Test1()
        {
            new SamplePage1(this)
                .Go()
                .Search("Mirabeau");
        }
    }
}
