﻿using FluentAutomation;

namespace $rootnamespace$
{
    internal class $safeitemname$ : PageObject<$safeitemname$>
    {
        private const string ExampleField = "q";

        public $safeitemname$(FluentTest test) : base(test)
        {
            Url = "http://www.google.com/";
            At = () => I.Assert.Visible(ExampleField);
        }


        public $safeitemname$ Search(string searchTerm)
        {
            I.Enter(searchTerm).In(ExampleField);
            return this;
        }


    }
}